package com.sdl.AUAS.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.sdl.AUAS.Model.Admin;
import com.sdl.AUAS.Repository.AdminRepo;

@Controller
public class AdminController {
	
	@Autowired
	AdminRepo arepo;
	@PostMapping("/LoginAdmin")
	public String LoginAdmin(@Valid @ModelAttribute("admin") Admin admin, Model model)
	{
		Admin admin1=new Admin();
		
		
		
		admin1=arepo.findByAdid(admin.getAdid());
		if(null!=admin1)
		{
			if(admin.getAdpassword().equals(admin1.getAdpassword()))
					
			{
				if(admin.getAdid()==1000000001)
				{
					return "admin/DeptOffice";
				}
				if(admin.getAdid()==1000000002)
				{
					return "admin/HostelOffice";
				}
				if(admin.getAdid()==1000000003)
				{
					return "admin/Library";
				}
			}
			else
			{
				String error = "Incorrect Password!";
				model.addAttribute("error" , error);
				return "admin/AdminLogin";
			}
					
		}
		else
		{
			String error = "Invalid ID!";
			model.addAttribute("error" , error);
			return "admin/AdminLogin";
		}
		return "admin/AdminLogin";
	}
	

}
