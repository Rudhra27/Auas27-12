package com.sdl.AUAS.Controller;

import java.sql.Timestamp;
import java.util.Base64;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.sdl.AUAS.Model.Department;
import com.sdl.AUAS.Model.Facultyid;
import com.sdl.AUAS.Model.General;
import com.sdl.AUAS.Model.Generalinfo;
import com.sdl.AUAS.Model.Library;
import com.sdl.AUAS.Model.Libraryinfo;
import com.sdl.AUAS.Model.Personalinfo;
import com.sdl.AUAS.Model.User;
import com.sdl.AUAS.Repository.DepartmentRepo;
import com.sdl.AUAS.Repository.FacultyidRepo;
import com.sdl.AUAS.Repository.GeneralRepo;
import com.sdl.AUAS.Repository.GeneralinfoRepo;
import com.sdl.AUAS.Repository.LibraryRepo;
import com.sdl.AUAS.Repository.LibraryinfoRepo;
import com.sdl.AUAS.Repository.PersonalinfoRepo;
import com.sdl.AUAS.Repository.UserRepository;
import com.sdl.AUAS.Service.PersonalService;
import com.sdl.AUAS.Service.UserService;

@Controller
public class FacultyController {
	
	

	@Autowired
	FacultyidRepo facultyrepo;
	@Autowired
	DepartmentRepo deptrepo;
	@Autowired
	GeneralRepo grepo;

	PersonalService personalservice;
	@Autowired
	PersonalinfoRepo personalrepo;
	@Autowired
	GeneralinfoRepo ginforepo;
	@Autowired
	LibraryinfoRepo libinforepo;
	@Autowired
	LibraryRepo librepo;
	@Autowired
	UserRepository repo;
	UserService userservice;
	
	@GetMapping("/addFaculty")
	public String signup()
	{
		return "users/FacultySignup";
	}
	@GetMapping("/LoginFaculty")
	public String login()
	{
		return "users/Faculty";
	}

	
	@PostMapping("/addFaculty")
	public String addFaculty(@Valid @ModelAttribute("user") User user,BindingResult br, Model model) {
		
		User user1= new User();
		user1=repo.findByUserid(user.getUserid());
		if(null!=user1)
		{
			String errormsg = "UserId already exist!";
			model.addAttribute("errormsg" , errormsg);
			return "users/FacultySignup";
			//br.rejectValue("userid", "error.user","UserId already exist.");		
		}
		else {
				Facultyid faculityid1 = new Facultyid();
				faculityid1 = facultyrepo.findByFacultyid(user.getUserid());
				if (null == faculityid1 )
					{
						String errormsg = "UserId does not exist!";
						model.addAttribute("errormsg" , errormsg);
						return "users/FacultySignup";
			//br.rejectValue("userid", "error.user","UserId does not exist.");		
					}
			
				else {
					if (user.getName().equals(faculityid1.getName())) {
						repo.save(user);
						String errormsg = "Registered Successfully!";
						model.addAttribute("errormsg" , errormsg);
					return "users/Faculty";
					}
					
					else 
					{
				
						String errormsg = "UserName is not matched with UserId!";
						model.addAttribute("errormsg" , errormsg);
						return "users/FacultySignup";
				//br.rejectValue("name", "error.user","UserName is not matched.");		
					}
			
				}
		 
		}
		
	}
	@PostMapping("/LoginFaculty")  
	public String LoginFaculty(@Valid @ModelAttribute("user") User user, Model model)
	{
		User user1=new User();
		user1=repo.findByUserid(user.getUserid());
		
		Long passuserid = user.getUserid();
		if(null!=user1)
		{
			if(user1.getPassword().equals(user.getPassword())) {
				model.addAttribute("passuserid", passuserid);
					return "users/FacultyQuery";
					}
			else
			{
				String error = "Incorrect Password!";
				model.addAttribute("error" , error);
				return "users/Faculty";
			}
					
		}
		else
		{
			String error = "Invalid ID!";
			model.addAttribute("error" , error);
			return "users/Faculty";
		}
		
	}
@GetMapping(value="/postCabin/{passuserid}")
public String cabin(@PathVariable("passuserid") String passuserid, Model model)
{
	model.addAttribute("passuserid", passuserid);	
return "users/cabin";	
}
@PostMapping("/postCabin")
public String postCabin(@RequestParam ("photo") MultipartFile file, @Valid @ModelAttribute Personalinfo personal , Model model)
{	
	
	Personalinfo p1=new Personalinfo();
	p1=personalrepo.findTopByOrderByIdDesc();
	
	 Timestamp date = new Timestamp(System.currentTimeMillis());
		personal.setStatus("Submitted");
		personal.setUtilDate(date);
		personalrepo.save(personal);
		
		
			   

		Department dept=new Department();
		
		//dept.setKey(personalrepo.findTopByOrderByIdDesc());
		
		dept.setKey(p1.getId());
		dept.setPlace(personal.getPlace());
		dept.setQuery(personal.getQuery());
		dept.setStatus("Received");
		dept.setUtilDate(date);
		//dept.getImage(personal.getImage());
		
		
		
try {
	 	byte[] image = file.getBytes();
	 	dept.setImage(image);
	 	personal.setImage(image);
	 	deptrepo.save(dept);
	 	personalrepo.save(personal);
   try {
	       byte[] encodeBase64 = Base64.getEncoder().encode(image);
	       String base64Encoded = new String(encodeBase64, "UTF-8");
	       model.addAttribute("userImage", base64Encoded );
	     } catch (Exception e) {
	          return "users/cabin";
	      }	     	 	
		int saveImage = personalservice.saveImage(personal);
    if (saveImage == 1) {
//               return "redirect:/";
    	return "redirect:/";
    } else {
        return "users/cabin";
    }
	} catch (Exception e) {
		return "users/cabin";

	}

	
	
	//return "users/Faculty";
	//,@RequestParam ("photo") MultipartFile file, Model model
	
	//Personalinfo personal2=new Personalinfo();
   
}
@PostMapping("/postLibraryQuery")
public String postLibraryQuery(Libraryinfo libraryinfo)
{
	Timestamp date = new Timestamp(System.currentTimeMillis());
	//Personalinfo personal2=new Personalinfo();
	libraryinfo.setStatus("Submitted");
	libraryinfo.setUtilDate(date);
	libinforepo.save(libraryinfo);
	
	
	Library lib=new Library();
	
	//dept.setKey(personalrepo.findTopByOrderByIdDesc());
	Libraryinfo l1=new Libraryinfo();
	l1=libinforepo.findTopByOrderByIdDesc();
	lib.setKey(l1.getId());
	lib.setAuthor(libraryinfo.getAuthor());
	lib.setBname(libraryinfo.getBname());
	lib.setEdition(libraryinfo.getEdition());
	
	lib.setStatus("Received");
	lib.setUtilDate(date);
	
	//dept.getImage(personal.getImage());
	librepo.save(lib);
	return"users/Faculty";
}

@PostMapping("/postGeneral")
public String postGeneral(Generalinfo generalinfo)
		 
{

	//,@RequestParam ("photo") MultipartFile file, Model model
	Timestamp date = new Timestamp(System.currentTimeMillis());
	//Personalinfo personal2=new Personalinfo();
	generalinfo.setStatus("Submitted");
	generalinfo.setUtilDate(date);
	generalinfo.setCount(1);
	ginforepo.save(generalinfo);
	
	
	General general= new General();
	
	//dept.setKey(personalrepo.findTopByOrderByIdDesc());
	Generalinfo g1=new Generalinfo();
	g1=ginforepo.findTopByOrderByIdDesc();
	general.setId(g1.getId());
	general.setPlace(generalinfo.getPlace());
	general.setQuery(generalinfo.getQuery());
	general.setCount(1);
	general.setStatus("Received");
	general.setUtilDate(date);
	
	//dept.getImage(personal.getImage());
	grepo.save(general);
	
	
	return "users/Faculty";
}
}/*
	 * @GetMapping("/facultylist") public String getFaculty() { Facultyid
	 * faculityid=new Facultyid(); ArrayList<Facultyid> facultylist=new
	 * ArrayList<Facultyid>(); facultylist=(ArrayList<Facultyid>)
	 * facultyrepo.findAll();
	 * System.out.println("values from faculty table:"+facultylist);
	 * Map<Long,Facultyid > map = new HashMap<Long,Facultyid>(); for (Facultyid
	 * facultyid : facultylist) { map.put(facultyid.getFacultyid(), facultyid); }
	 * System.out.println("values stored to map:"+map);
	 * faculityid=map.get(user.getUserid());
	 * System.out.println("name :"+faculityid.getName());
	 * 
	 * }
	 */
	// System.out.println(user);
	// model.addAttribute("user", user);
	// Long id=user.getUserid();
	// if (id.equals(Facultyid.getFacultyid()))

