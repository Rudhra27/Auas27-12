package com.sdl.AUAS.Controller;

import java.sql.Timestamp;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.sdl.AUAS.Model.Department;
import com.sdl.AUAS.Model.Personalinfo;
import com.sdl.AUAS.Model.Staff;
import com.sdl.AUAS.Model.Staffid;
import com.sdl.AUAS.Repository.DepartmentRepo;
import com.sdl.AUAS.Repository.PersonalinfoRepo;
import com.sdl.AUAS.Repository.StaffRepo;
import com.sdl.AUAS.Repository.StaffidRepo;
import com.sdl.AUAS.Service.UserService;
@Controller
public class StaffController {
	

	@Autowired
	StaffidRepo staffidrepo;
	@Autowired
	DepartmentRepo deptrepo;
	@Autowired
	PersonalinfoRepo personalrepo;

	@Autowired
	StaffRepo staffrepo;
	UserService userservice;

	@GetMapping("/addStaff")
	public String signup()
	{
		return "staff/StaffSignup";
	}
	@GetMapping("/LoginStaff")
	public String login()
	{
		return "staff/Staff";
	}
	
	@PostMapping("/addStaff")
	public String addFaculty(@Valid  @ModelAttribute("staff") Staff staff,BindingResult br, Model model) {

	
		Staff staff1= new Staff();
		staff1=staffrepo.findBySfid(staff.getSfid());
		if(null!=staff1)
		{
			String errormsg = "UserId already exist!";
			model.addAttribute("errormsg" , errormsg);
			return "staff/StaffSignup";		
		}
		
		else {
		Staffid staffid1 = new Staffid();
		staffid1 = staffidrepo.findByStaffid(staff.getSfid());
		if (null == staffid1 )
		{
			String errormsg = "UserId does not exist!";
			model.addAttribute("errormsg" , errormsg);
			return "staff/StaffSignup";
			//br.rejectValue("userid", "error.user","UserId does not exist.");
			
		}
		
		else {
			if (staff.getSfname().equals(staffid1.getStaffName())) {
				staffrepo.save(staff);
				String errormsg = "Registered Successfully!";
				model.addAttribute("errormsg" , errormsg);
				return "staff/Staff";
			} else {
				String errormsg = "UserName is not matched with UserId!";
				model.addAttribute("errormsg" , errormsg);
				return "staff/StaffSignup";
				//br.rejectValue("name", "error.user","UserName is not matched.");		
			}
			
		}
		}
	}
	@PostMapping("/LoginStaff")
	public String LoginFaculty(@Valid @ModelAttribute("staff") Staff staff, Model model)
	{
		Staff staff1= new Staff();
		staff1=staffrepo.findBySfid(staff.getSfid());
		if(null!=staff1)
		{
			if(staff1.getSfpassword().equals(staff.getSfpassword()))
					return "staff/StaffQuery";
			else
			{
				String error = "Incorrect Password!";
				model.addAttribute("error" , error);
				return "staff/Staff";
			}
					
		}
		else
		{
			String error = "Invalid ID!";
			model.addAttribute("error" , error);
			return "staff/Staff";
		} 
	}
	@GetMapping("/postOffice")
	public String postOffice()
	{
		return "staff/Office";
	}
	@PostMapping("/postOffice")
	public String postOffice(Personalinfo personal)
			 
	{

		//,@RequestParam ("photo") MultipartFile file, Model model
		Timestamp date = new Timestamp(System.currentTimeMillis());
		
		//Personalinfo personal2=new Personalinfo();
		personal.setStatus("Submitted");
		personal.setUtilDate(date);
		personalrepo.save(personal);
		
		
		Department dept=new Department();
		
		//dept.setKey(personalrepo.findTopByOrderByIdDesc());
		Personalinfo p1=new Personalinfo();
		p1=personalrepo.findTopByOrderByIdDesc();
		dept.setKey(p1.getId());
		dept.setPlace(personal.getPlace());
		dept.setQuery(personal.getQuery());
		dept.setStatus("Received");
		dept.setUtilDate(date);
		
		//dept.getImage(personal.getImage());
		deptrepo.save(dept);
		return "staff/StaffQuery";
	}
}
