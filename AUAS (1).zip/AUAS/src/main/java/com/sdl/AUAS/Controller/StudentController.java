package com.sdl.AUAS.Controller;

import java.sql.Timestamp;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.sdl.AUAS.Model.Department;
import com.sdl.AUAS.Model.Personalinfo;
import com.sdl.AUAS.Model.Student;
import com.sdl.AUAS.Model.Studentid;
import com.sdl.AUAS.Repository.DepartmentRepo;
import com.sdl.AUAS.Repository.PersonalinfoRepo;
import com.sdl.AUAS.Repository.StudentRepo;
import com.sdl.AUAS.Repository.StudentidRepo;
import com.sdl.AUAS.Service.UserService;



@Controller
public class StudentController {
	@Autowired
	DepartmentRepo deptrepo;
	@Autowired
	PersonalinfoRepo personalrepo;
	@Autowired
	StudentidRepo studentidrepo;
	@Autowired
	StudentRepo stdrepo;
	UserService userservice;
	
	@GetMapping("/addStudent")
	public String signup()
	{
		return "students/StudentSignup";
	}
	@GetMapping("/LoginStudent")
	public String login()
	{
		return "students/Student";
	}
	
	@PostMapping("/addStudent")
	public String addFaculty(@Valid  @ModelAttribute("student") Student student,BindingResult br, Model model) {

	
		Student student1= new Student();
		student1=stdrepo.findBySid(student.getSid());
		if(null!=student1)
		{
			String errormsg = "UserId already exist!";
			model.addAttribute("errormsg" , errormsg);
			return "students/StudentSignup";		
		}
		
		else {
		Studentid studentid1 = new Studentid();
		studentid1 = studentidrepo.findByStudentid(student.getSid());
		if (null == studentid1 )
		{
			String errormsg = "UserId does not exist!";
			model.addAttribute("errormsg" , errormsg);
			return "students/StudentSignup";
			//br.rejectValue("userid", "error.user","UserId does not exist.");
			
		}
		
		else {
			if (student.getSname().equals(studentid1.getStudentName())) {
				stdrepo.save(student);
				String errormsg = "Registered Successfully!";
				model.addAttribute("errormsg" , errormsg);
				return "students/Student";
			} 
			else {
				String errormsg = "UserName is not matched with UserId!";
				model.addAttribute("errormsg" , errormsg);
				return "students/StudentSignup";
				//br.rejectValue("name", "error.user","UserName is not matched.");		
			}
			
		}
		}
	}

	@PostMapping("/LoginStudent")
	public String LoginFaculty(@Valid @ModelAttribute("student") Student student, Model model)
	{
		Student student1= new Student();
		student1=stdrepo.findBySid(student.getSid());
		if(null!=student1)
		{
			if(student1.getSpassword().equals(student.getSpassword()))
					return "students/StudentQuery";
			else
			{
				String error = "Incorrect Password!";
				model.addAttribute("error" , error);
				return "students/Student";
			}
					
		}
		else
		{
			String error = "Invalid ID!";
			model.addAttribute("error" , error);
			return "students/Student";
		}
		
	}
	@GetMapping("/postClassroom")
	public String postClassroom()
	{
		return "students/classroom";
	}
	@GetMapping("/postHostel")
	public String postHostel()
	{
		return "students/Student";
	}
	

@PostMapping("/postClassroom")
public String postClassroom(Personalinfo personal)
		 
{

	//,@RequestParam ("photo") MultipartFile file, Model model
	Timestamp date = new Timestamp(System.currentTimeMillis());
	
	//Personalinfo personal2=new Personalinfo();
	personal.setStatus("Submitted");
	personal.setUtilDate(date);
	personalrepo.save(personal);
	
	
	Department dept=new Department();
	
	//dept.setKey(personalrepo.findTopByOrderByIdDesc());
	Personalinfo p1=new Personalinfo();
	p1=personalrepo.findTopByOrderByIdDesc();
	dept.setKey(p1.getId());
	dept.setPlace(personal.getPlace());
	dept.setQuery(personal.getQuery());
	dept.setStatus("Received");
	dept.setUtilDate(date);
	
	//dept.getImage(personal.getImage());
	deptrepo.save(dept);
	
	
	return "students/StudentQuery";
}
}