package com.sdl.AUAS.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sdl.AUAS.Model.Facultyid;
import com.sdl.AUAS.Model.User;
import com.sdl.AUAS.Repository.UserRepository;
import com.sdl.AUAS.Service.UserService;

@Controller
public class UserController {
	
	@Autowired
	UserRepository repo;
	UserService userservice;
	
	@RequestMapping("/")
	public String home(HttpServletRequest request)
	{
		return "index.html";
	}
	
	@GetMapping("/Admin")
	public String admin()
	{
		return "admin/AdminLogin";
	}
	
	@GetMapping("/Faculty")
	public String faculty()
	{
		return "users/Faculty";
	}
	@GetMapping("/Staff")
	public String staff()
	{
		return "staff/Staff";
	}
	@GetMapping("/Student")
	public String student()
	{
		return "students/Student";
	}
	@GetMapping("/homepage")
	public String homepage()
	{
		return "index";
	}
	@GetMapping("/postGeneral")
	public String postGeneral()
	{
		return "users/General";
	}
	
	@GetMapping("/postLibrary")
	public String postLibrary()
	{
		return "users/FLibrary";
	}
    @GetMapping("/SQuery")
    public String SQuery()
    {
    	return "students/StudentQuery";
    }
    @GetMapping("/SffQuery")
    public String SffQuery()
    {
    	return "staff/StaffQuery";
    }
    @GetMapping("/FQuery")
    public String FQuery()
    {
    	return "users/FacultyQuery";
    }
    
}
