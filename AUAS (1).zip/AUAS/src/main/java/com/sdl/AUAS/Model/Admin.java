package com.sdl.AUAS.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="admin")
public class Admin {
	
	@Id
	public long adid;
	public String adpassword;
	
	
	@Override
	public String toString() {
		return "Admin [adid=" + adid + ", adpassword=" + adpassword + "]";
	}


	public long getAdid() {
		return adid;
	}


	public void setAdid(long adid) {
		this.adid = adid;
	}


	public String getAdpassword() {
		return adpassword;
	}


	public void setAdpassword(String adpassword) {
		this.adpassword = adpassword;
	}


	public Admin(long adid, String adpassword) {
		super();
		this.adid = adid;
		this.adpassword = adpassword;
	}


	public Admin()
	{
		
	}
	
	
	

}
