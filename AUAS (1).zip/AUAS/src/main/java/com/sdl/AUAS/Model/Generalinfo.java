package com.sdl.AUAS.Model;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table (name="deptgeneral")
public class Generalinfo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@SequenceGenerator(name="product_generator", sequenceName = "product_seq")
	private long id;
	 private long userid;
	@Column(name="Time")
	 @Temporal(TemporalType.TIMESTAMP)
	    private Date utilDate;
	private String place;
		private String query;
	@Lob
	  @Column(name = "image")
	  private byte[] image;
	private int count;
	private String status;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public Date getUtilDate() {
		return utilDate;
	}
	public void setUtilDate(Date utilDate) {
		this.utilDate = utilDate;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Generalinfo [id=" + id + ", userid=" + userid + ", utilDate=" + utilDate + ", place=" + place
				+ ", query=" + query + ", image=" + Arrays.toString(image) + ", count=" + count + ", status=" + status
				+ "]";
	}
	public Generalinfo(long id, long userid, Date utilDate, String place, String query, byte[] image, int count,
			String status) {
		super();
		this.id = id;
		this.userid = userid;
		this.utilDate = utilDate;
		this.place = place;
		this.query = query;
		this.image = image;
		this.count = count;
		this.status = status;
	}
	public Generalinfo()
	{
		
	}
	
}
