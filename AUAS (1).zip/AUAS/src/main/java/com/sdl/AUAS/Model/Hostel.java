package com.sdl.AUAS.Model;

public class Hostel {

}
