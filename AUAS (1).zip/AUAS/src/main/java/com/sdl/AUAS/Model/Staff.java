package com.sdl.AUAS.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity	
@Table(name="staff", schema="public")
public class Staff {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private Long sfid;
	private String sfname;
	private String sfemail;
	private String sfpassword;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Long getSfid() {
		return sfid;
	}
	public void setSfid(Long sfid) {
		this.sfid = sfid;
	}
	public String getSfname() {
		return sfname;
	}
	public void setSfname(String sfname) {
		this.sfname = sfname;
	}
	public String getSfemail() {
		return sfemail;
	}
	public void setSfemail(String sfemail) {
		this.sfemail = sfemail;
	}
	public String getSfpassword() {
		return sfpassword;
	}
	public void setSfpassword(String sfpassword) {
		this.sfpassword = sfpassword;
	}
	public Staff(int id, Long sfid, String sfname, String sfemail, String sfpassword) {
		super();
		this.id = id;
		this.sfid = sfid;
		this.sfname = sfname;
		this.sfemail = sfemail;
		this.sfpassword = sfpassword;
	}
	
	public Staff()
	{
		
	}
	@Override
	public String toString() {
		return "Staff [id=" + id + ", sfid=" + sfid + ", sfname=" + sfname + ", sfemail=" + sfemail + ", sfpassword="
				+ sfpassword + "]";
	}
	
}
