package com.sdl.AUAS.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity	
@Table(name="student", schema="public")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private Long sid;
	private String sname;
	private String semail;
	private String spassword;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Long getSid() {
		return sid;
	}
	public void setSid(Long sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	public String getSpassword() {
		return spassword;
	}
	public void setSpassword(String spassword) {
		this.spassword = spassword;
	}
	public Student()
	{
		
	}
	public Student(int id, Long sid, String sname, String semail, String spassword) {
		super();
		this.id = id;
		this.sid = sid;
		this.sname = sname;
		this.semail = semail;
		this.spassword = spassword;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", sid=" + sid + ", sname=" + sname + ", semail=" + semail + ", spassword="
				+ spassword + "]";
	}
	
	


}
