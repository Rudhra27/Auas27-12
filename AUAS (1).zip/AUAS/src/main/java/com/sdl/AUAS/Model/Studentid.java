package com.sdl.AUAS.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="studentid")
public class Studentid {
	
	@Id
	public Long studentid;
	public String studentName;
	public Long getStudentid() {
		return studentid;
	}
	public void setStudentid(Long studentid) {
		this.studentid = studentid;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	@Override
	public String toString() {
		return "Studentid [studentid=" + studentid + ", studentName=" + studentName + "]";
	}
	
	

}
