package com.sdl.AUAS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sdl.AUAS.Model.Department;
import com.sdl.AUAS.Model.Personalinfo;

@Repository
public interface PersonalinfoRepo extends JpaRepository<Personalinfo,Long>{

	

	Personalinfo findTopByOrderByIdDesc();




}
