package com.sdl.AUAS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sdl.AUAS.Model.Staffid;
@Repository
public interface StaffidRepo extends JpaRepository <Staffid,Long>{

	Staffid findByStaffid(Long sfid);

}
