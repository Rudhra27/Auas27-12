package com.sdl.AUAS.Service;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sdl.AUAS.Model.Personalinfo;
import com.sdl.AUAS.Repository.PersonalinfoRepo;


@Repository
public class PersonalService {
	private PersonalinfoRepo prepo;
	 @Autowired
	  public void setPersonalinfoRepo(PersonalinfoRepo prepo) {
	    this.prepo = prepo;
	 }
		public int saveImage(Personalinfo personal) {
			
		      try {
		          prepo.save(personal);
		          return 1;
		      } catch (Exception e) {
		           return 0;
		      }
	
	}
}
